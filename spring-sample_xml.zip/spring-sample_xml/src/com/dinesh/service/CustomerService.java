package com.dinesh.service;

import java.util.List;

import com.dinesh.model.Customer;

public interface CustomerService {

	List<Customer> findAll();

}